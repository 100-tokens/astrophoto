#feature-id    AstrophotoPublisher : Astrophoto > Publish to Astrophoto

#feature-info  Publish the active XISF image to Astrophoto with \
   prefilled acquisition metadata. Requires a personal access token \
   from your Astrophoto settings page.

#include <pjsr/Sizer.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/DataType.jsh>

#include "lib/APHttp.js"
#include "lib/APStore.js"
#include "lib/APMeta.js"
#include "lib/APFlow.js"
#include "lib/APDialog.js"

function main()
{
   let window = ImageWindow.activeWindow;
   if ( window.isNull )
   {
      ( new MessageBox( "Open the image you want to publish first.",
                        "Astrophoto Publisher", StdIcon_Error, StdButton_Ok ) ).execute();
      return;
   }
   let dialog = new APDialog( window );
   dialog.execute();
}

main();
